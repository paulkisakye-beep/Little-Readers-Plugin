# Little Readers UG Plugin Installation

## Quick Start

1. Download the plugin ZIP file
2. In WordPress admin, go to Plugins > Add New
3. Click "Upload Plugin" and select the ZIP file
4. Activate the plugin
5. Go to Settings > Little Readers to configure
6. Add `[little_readers_store]` shortcode to your page

## Configuration

- **Backend URL**: Your Google Apps Script web app URL
- **API Key**: Your API key (default: LRU_WebApp_Key_2025)

## Support

For help and support, visit the plugin documentation or contact support.
