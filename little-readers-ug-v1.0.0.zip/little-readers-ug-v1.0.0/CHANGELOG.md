# Changelog

## Version 1.0.0 (2025-09-23)

### Added
- Initial release of Little Readers UG WordPress plugin
- Complete bookstore functionality with Google Apps Script integration
- Shopping cart with persistent storage
- Checkout system with delivery options
- Promo code support with discount calculations
- Responsive design for all devices
- Caching system for performance optimization
- Admin configuration panel
- WhatsApp integration for customer support

### Features
- Book grid with filtering and search
- Dynamic delivery area selection
- Order processing and SMS notifications
- Mobile-friendly responsive design
- Security features and input sanitization
